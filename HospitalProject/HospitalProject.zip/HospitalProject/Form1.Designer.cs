﻿
namespace HospitalProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtHospital_Name = new System.Windows.Forms.TextBox();
            this.txtHospital_Address = new System.Windows.Forms.TextBox();
            this.txtHospital_Phone_Number = new System.Windows.Forms.TextBox();
            this.txtState = new System.Windows.Forms.TextBox();
            this.btnActionHospital = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtHospital_ID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnActionDoctor = new System.Windows.Forms.Button();
            this.txt_Doctor_Phone_Number = new System.Windows.Forms.TextBox();
            this.txt_Doctor_Department_ID = new System.Windows.Forms.TextBox();
            this.txt_Doctor_Last_Name = new System.Windows.Forms.TextBox();
            this.txtDoctor_First_Name = new System.Windows.Forms.TextBox();
            this.txtDoctor_ID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnActionDepartment = new System.Windows.Forms.Button();
            this.txtDepartment_Name = new System.Windows.Forms.TextBox();
            this.txtDepartment_ID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnActionStaff = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnActionAppointment = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_Doctor_Id = new System.Windows.Forms.TextBox();
            this.txtPatient_ID = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnActionPatient = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.RadioButton();
            this.btnRemove = new System.Windows.Forms.RadioButton();
            this.btnSelect = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.txtUseHospital = new System.Windows.Forms.TextBox();
            this.btnUseHospital = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.lblUsedDB = new System.Windows.Forms.Label();
            this.comboBox_Hospital_Name = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(26, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Hospital_Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(23, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hospital_Address";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(20, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Hospital_Phone_Number";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(23, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "State";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtHospital_Name
            // 
            this.txtHospital_Name.Location = new System.Drawing.Point(204, 119);
            this.txtHospital_Name.Name = "txtHospital_Name";
            this.txtHospital_Name.Size = new System.Drawing.Size(100, 20);
            this.txtHospital_Name.TabIndex = 6;
            // 
            // txtHospital_Address
            // 
            this.txtHospital_Address.Location = new System.Drawing.Point(204, 166);
            this.txtHospital_Address.Name = "txtHospital_Address";
            this.txtHospital_Address.Size = new System.Drawing.Size(100, 20);
            this.txtHospital_Address.TabIndex = 7;
            // 
            // txtHospital_Phone_Number
            // 
            this.txtHospital_Phone_Number.Location = new System.Drawing.Point(204, 215);
            this.txtHospital_Phone_Number.Name = "txtHospital_Phone_Number";
            this.txtHospital_Phone_Number.Size = new System.Drawing.Size(100, 20);
            this.txtHospital_Phone_Number.TabIndex = 8;
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(204, 265);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(100, 20);
            this.txtState.TabIndex = 9;
            // 
            // btnActionHospital
            // 
            this.btnActionHospital.Location = new System.Drawing.Point(104, 341);
            this.btnActionHospital.Name = "btnActionHospital";
            this.btnActionHospital.Size = new System.Drawing.Size(149, 23);
            this.btnActionHospital.TabIndex = 12;
            this.btnActionHospital.Text = "Register";
            this.btnActionHospital.UseVisualStyleBackColor = true;
            this.btnActionHospital.Click += new System.EventHandler(this.btnActionHospital_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(397, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(396, 410);
            this.tabControl1.TabIndex = 13;
            this.tabControl1.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnActionHospital);
            this.tabPage1.Controls.Add(this.txtState);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtHospital_Name);
            this.tabPage1.Controls.Add(this.txtHospital_Phone_Number);
            this.tabPage1.Controls.Add(this.txtHospital_ID);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtHospital_Address);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(388, 384);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Hospital";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtHospital_ID
            // 
            this.txtHospital_ID.Location = new System.Drawing.Point(204, 71);
            this.txtHospital_ID.Name = "txtHospital_ID";
            this.txtHospital_ID.Size = new System.Drawing.Size(100, 20);
            this.txtHospital_ID.TabIndex = 5;
            this.txtHospital_ID.UseWaitCursor = true;
            this.txtHospital_ID.Visible = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(23, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hospital_ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.UseWaitCursor = true;
            this.label1.Visible = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnActionDoctor);
            this.tabPage2.Controls.Add(this.txt_Doctor_Phone_Number);
            this.tabPage2.Controls.Add(this.txt_Doctor_Department_ID);
            this.tabPage2.Controls.Add(this.txt_Doctor_Last_Name);
            this.tabPage2.Controls.Add(this.txtDoctor_First_Name);
            this.tabPage2.Controls.Add(this.txtDoctor_ID);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(388, 384);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Doctor";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnActionDoctor
            // 
            this.btnActionDoctor.Location = new System.Drawing.Point(144, 299);
            this.btnActionDoctor.Name = "btnActionDoctor";
            this.btnActionDoctor.Size = new System.Drawing.Size(123, 23);
            this.btnActionDoctor.TabIndex = 21;
            this.btnActionDoctor.Text = "Register Doctor";
            this.btnActionDoctor.UseVisualStyleBackColor = true;
            this.btnActionDoctor.Click += new System.EventHandler(this.btnActionDoctor_Click);
            // 
            // txt_Doctor_Phone_Number
            // 
            this.txt_Doctor_Phone_Number.Location = new System.Drawing.Point(222, 229);
            this.txt_Doctor_Phone_Number.Name = "txt_Doctor_Phone_Number";
            this.txt_Doctor_Phone_Number.Size = new System.Drawing.Size(100, 20);
            this.txt_Doctor_Phone_Number.TabIndex = 20;
            // 
            // txt_Doctor_Department_ID
            // 
            this.txt_Doctor_Department_ID.Location = new System.Drawing.Point(222, 190);
            this.txt_Doctor_Department_ID.Name = "txt_Doctor_Department_ID";
            this.txt_Doctor_Department_ID.Size = new System.Drawing.Size(100, 20);
            this.txt_Doctor_Department_ID.TabIndex = 19;
            // 
            // txt_Doctor_Last_Name
            // 
            this.txt_Doctor_Last_Name.Location = new System.Drawing.Point(222, 147);
            this.txt_Doctor_Last_Name.Name = "txt_Doctor_Last_Name";
            this.txt_Doctor_Last_Name.Size = new System.Drawing.Size(100, 20);
            this.txt_Doctor_Last_Name.TabIndex = 18;
            // 
            // txtDoctor_First_Name
            // 
            this.txtDoctor_First_Name.Location = new System.Drawing.Point(222, 104);
            this.txtDoctor_First_Name.Name = "txtDoctor_First_Name";
            this.txtDoctor_First_Name.Size = new System.Drawing.Size(100, 20);
            this.txtDoctor_First_Name.TabIndex = 17;
            // 
            // txtDoctor_ID
            // 
            this.txtDoctor_ID.Location = new System.Drawing.Point(222, 63);
            this.txtDoctor_ID.Name = "txtDoctor_ID";
            this.txtDoctor_ID.Size = new System.Drawing.Size(100, 20);
            this.txtDoctor_ID.TabIndex = 16;
            this.txtDoctor_ID.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(67, 232);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Phone number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(67, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Department_ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(67, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Doctor_Last_Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(67, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Doctor_First_Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(67, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Doctor_ID";
            this.label10.Visible = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.comboBox_Hospital_Name);
            this.tabPage3.Controls.Add(this.btnActionDepartment);
            this.tabPage3.Controls.Add(this.txtDepartment_Name);
            this.tabPage3.Controls.Add(this.txtDepartment_ID);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(388, 384);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Department";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnActionDepartment
            // 
            this.btnActionDepartment.Location = new System.Drawing.Point(154, 347);
            this.btnActionDepartment.Name = "btnActionDepartment";
            this.btnActionDepartment.Size = new System.Drawing.Size(75, 23);
            this.btnActionDepartment.TabIndex = 14;
            this.btnActionDepartment.Text = "Register";
            this.btnActionDepartment.UseVisualStyleBackColor = true;
            // 
            // txtDepartment_Name
            // 
            this.txtDepartment_Name.Location = new System.Drawing.Point(195, 138);
            this.txtDepartment_Name.Name = "txtDepartment_Name";
            this.txtDepartment_Name.Size = new System.Drawing.Size(131, 20);
            this.txtDepartment_Name.TabIndex = 12;
            // 
            // txtDepartment_ID
            // 
            this.txtDepartment_ID.Location = new System.Drawing.Point(195, 84);
            this.txtDepartment_ID.Name = "txtDepartment_ID";
            this.txtDepartment_ID.Size = new System.Drawing.Size(100, 20);
            this.txtDepartment_ID.TabIndex = 11;
            this.txtDepartment_ID.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(57, 189);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Hospital_Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(57, 138);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Department_Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(57, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Department_ID";
            this.label13.Visible = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnActionStaff);
            this.tabPage4.Controls.Add(this.textBox6);
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Controls.Add(this.textBox7);
            this.tabPage4.Controls.Add(this.textBox8);
            this.tabPage4.Controls.Add(this.textBox9);
            this.tabPage4.Controls.Add(this.textBox10);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(388, 384);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Staff";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnActionStaff
            // 
            this.btnActionStaff.Location = new System.Drawing.Point(251, 333);
            this.btnActionStaff.Name = "btnActionStaff";
            this.btnActionStaff.Size = new System.Drawing.Size(75, 23);
            this.btnActionStaff.TabIndex = 25;
            this.btnActionStaff.Text = "Register";
            this.btnActionStaff.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(236, 38);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 24;
            this.textBox6.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(236, 261);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 23;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(236, 219);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 22;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(236, 169);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 20);
            this.textBox8.TabIndex = 21;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(236, 129);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 20);
            this.textBox9.TabIndex = 20;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(236, 87);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(53, 261);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 13);
            this.label14.TabIndex = 18;
            this.label14.Text = "Staff_Phone_Number";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(53, 222);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "Staff_Address";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(53, 176);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "Staff_Last_Name";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(53, 129);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(88, 13);
            this.label17.TabIndex = 15;
            this.label17.Text = "Staff_First_Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(53, 87);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 13);
            this.label18.TabIndex = 14;
            this.label18.Text = "Department_ID";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(53, 38);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 13;
            this.label19.Text = "Staff_ID";
            this.label19.Visible = false;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnActionAppointment);
            this.tabPage5.Controls.Add(this.label22);
            this.tabPage5.Controls.Add(this.dateTimePicker1);
            this.tabPage5.Controls.Add(this.txt_Doctor_Id);
            this.tabPage5.Controls.Add(this.txtPatient_ID);
            this.tabPage5.Controls.Add(this.label21);
            this.tabPage5.Controls.Add(this.label20);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(388, 384);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Appointment";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnActionAppointment
            // 
            this.btnActionAppointment.Location = new System.Drawing.Point(137, 284);
            this.btnActionAppointment.Name = "btnActionAppointment";
            this.btnActionAppointment.Size = new System.Drawing.Size(98, 23);
            this.btnActionAppointment.TabIndex = 6;
            this.btnActionAppointment.Text = "Do action";
            this.btnActionAppointment.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(35, 168);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 13);
            this.label22.TabIndex = 5;
            this.label22.Text = "Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(119, 162);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // txt_Doctor_Id
            // 
            this.txt_Doctor_Id.Location = new System.Drawing.Point(137, 108);
            this.txt_Doctor_Id.Name = "txt_Doctor_Id";
            this.txt_Doctor_Id.Size = new System.Drawing.Size(100, 20);
            this.txt_Doctor_Id.TabIndex = 3;
            // 
            // txtPatient_ID
            // 
            this.txtPatient_ID.Location = new System.Drawing.Point(137, 49);
            this.txtPatient_ID.Name = "txtPatient_ID";
            this.txtPatient_ID.Size = new System.Drawing.Size(100, 20);
            this.txtPatient_ID.TabIndex = 2;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(17, 115);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(95, 13);
            this.label21.TabIndex = 1;
            this.label21.Text = "Doctor_Full_Name";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(17, 52);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Patient_Full_Name";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.btnActionPatient);
            this.tabPage6.Controls.Add(this.textBox16);
            this.tabPage6.Controls.Add(this.textBox15);
            this.tabPage6.Controls.Add(this.textBox14);
            this.tabPage6.Controls.Add(this.textBox13);
            this.tabPage6.Controls.Add(this.textBox12);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.label24);
            this.tabPage6.Controls.Add(this.label23);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(388, 384);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Patient";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // btnActionPatient
            // 
            this.btnActionPatient.Location = new System.Drawing.Point(158, 297);
            this.btnActionPatient.Name = "btnActionPatient";
            this.btnActionPatient.Size = new System.Drawing.Size(75, 23);
            this.btnActionPatient.TabIndex = 11;
            this.btnActionPatient.Text = "button1";
            this.btnActionPatient.UseVisualStyleBackColor = true;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(235, 186);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 20);
            this.textBox16.TabIndex = 10;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(235, 148);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 9;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(235, 109);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 20);
            this.textBox14.TabIndex = 8;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(235, 67);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 20);
            this.textBox13.TabIndex = 7;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(235, 25);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 6;
            this.textBox12.Visible = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(16, 189);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(120, 13);
            this.label27.TabIndex = 4;
            this.label27.Text = "Patient_Phone_Number";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(16, 151);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(84, 13);
            this.label26.TabIndex = 3;
            this.label26.Text = "Patient_Address";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(16, 112);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 13);
            this.label25.TabIndex = 2;
            this.label25.Text = "Patient_Last_Name";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(16, 35);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "Patient_ID";
            this.label24.Visible = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(16, 70);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(99, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Patient_First_Name";
            // 
            // btnRegister
            // 
            this.btnRegister.AutoSize = true;
            this.btnRegister.Location = new System.Drawing.Point(4, 3);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(64, 17);
            this.btnRegister.TabIndex = 16;
            this.btnRegister.TabStop = true;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // btnRemove
            // 
            this.btnRemove.AutoSize = true;
            this.btnRemove.Location = new System.Drawing.Point(152, 3);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(65, 17);
            this.btnRemove.TabIndex = 17;
            this.btnRemove.TabStop = true;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.CheckedChanged += new System.EventHandler(this.btnRemove_CheckedChanged);
            // 
            // btnSelect
            // 
            this.btnSelect.AutoSize = true;
            this.btnSelect.Location = new System.Drawing.Point(91, 3);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(55, 17);
            this.btnSelect.TabIndex = 18;
            this.btnSelect.TabStop = true;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.CheckedChanged += new System.EventHandler(this.btnSelect_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnRegister);
            this.panel1.Controls.Add(this.btnRemove);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Location = new System.Drawing.Point(25, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(275, 34);
            this.panel1.TabIndex = 19;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(26, 105);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(224, 13);
            this.label28.TabIndex = 13;
            this.label28.Text = "Enter the name of the hospital you wish to use";
            // 
            // txtUseHospital
            // 
            this.txtUseHospital.Location = new System.Drawing.Point(29, 131);
            this.txtUseHospital.Multiline = true;
            this.txtUseHospital.Name = "txtUseHospital";
            this.txtUseHospital.Size = new System.Drawing.Size(246, 20);
            this.txtUseHospital.TabIndex = 20;
            // 
            // btnUseHospital
            // 
            this.btnUseHospital.Location = new System.Drawing.Point(84, 178);
            this.btnUseHospital.Name = "btnUseHospital";
            this.btnUseHospital.Size = new System.Drawing.Size(87, 42);
            this.btnUseHospital.TabIndex = 21;
            this.btnUseHospital.Text = "Use";
            this.btnUseHospital.UseVisualStyleBackColor = true;
            this.btnUseHospital.Click += new System.EventHandler(this.btnUseHospital_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(15, 291);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(171, 20);
            this.label29.TabIndex = 22;
            this.label29.Text = "Current hospital in use:";
            // 
            // lblUsedDB
            // 
            this.lblUsedDB.AutoSize = true;
            this.lblUsedDB.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsedDB.Location = new System.Drawing.Point(23, 326);
            this.lblUsedDB.Name = "lblUsedDB";
            this.lblUsedDB.Size = new System.Drawing.Size(88, 31);
            this.lblUsedDB.TabIndex = 23;
            this.lblUsedDB.Text = "empty";
            // 
            // comboBox_Hospital_Name
            // 
            this.comboBox_Hospital_Name.FormattingEnabled = true;
            this.comboBox_Hospital_Name.Location = new System.Drawing.Point(195, 189);
            this.comboBox_Hospital_Name.Name = "comboBox_Hospital_Name";
            this.comboBox_Hospital_Name.Size = new System.Drawing.Size(131, 21);
            this.comboBox_Hospital_Name.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblUsedDB);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.btnUseHospital);
            this.Controls.Add(this.txtUseHospital);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Hospital";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtHospital_Name;
        private System.Windows.Forms.TextBox txtHospital_Address;
        private System.Windows.Forms.TextBox txtHospital_Phone_Number;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Button btnActionHospital;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnActionDoctor;
        private System.Windows.Forms.TextBox txt_Doctor_Phone_Number;
        private System.Windows.Forms.TextBox txt_Doctor_Department_ID;
        private System.Windows.Forms.TextBox txt_Doctor_Last_Name;
        private System.Windows.Forms.TextBox txtDoctor_First_Name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnActionDepartment;
        private System.Windows.Forms.TextBox txtDepartment_Name;
        private System.Windows.Forms.TextBox txtDepartment_ID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnActionStaff;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnActionAppointment;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txt_Doctor_Id;
        private System.Windows.Forms.TextBox txtPatient_ID;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnActionPatient;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.RadioButton btnRegister;
        private System.Windows.Forms.RadioButton btnRemove;
        private System.Windows.Forms.RadioButton btnSelect;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtUseHospital;
        private System.Windows.Forms.Button btnUseHospital;
        private System.Windows.Forms.TextBox txtHospital_ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDoctor_ID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblUsedDB;
        private System.Windows.Forms.ComboBox comboBox_Hospital_Name;
    }
}

